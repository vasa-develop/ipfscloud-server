<!DOCTYPE html>
<html>

<head>
  <meta charset="UTF-8">
  <title>AES Example</title>
</head>

<body>
  <h1>AES Example</h1>
  <div>
    <H1> Select image or text file to download in zip folder.
  </div>
  <div>
    <input name="file" type="file" id="encrypt">
    <button id="submit">Submit</button>
  </div>
  <div>
    <H1> Select downloaded zip folder to upload.
  </div>
  <div>
    <form>
      <input name="docId" type="text" id="docId">
      <input type="submit" name="submit" value="Upload">
    </form>
  </div>
  <img id="image" height="100" width="100">
  <p id="result"></p>
  <script type="text/javascript" src="js/lib/excluded/jquery-2.1.3.min.js"></script>
  <script type="text/javascript" src="js/lib/aes.js"></script>
  <script type="text/javascript" src="js/lib/pbkdf2.js"></script>
  <script type="text/javascript" src="js/AesUtil.js"></script>
  <script type="text/javascript" src="./node_modules/jszip/dist/jszip.js"></script>
  <script type="text/javascript" src="./node_modules/jszip/dist/jszip-utils.js"></script>
  <script type="text/javascript">
    $(document).ready(function () {
      var iv = "F27D5C9927726BCEFE7510B1BDD3D137";
      var salt = "3FF2EC019C627B945225DEBAD71A01B6985FE84C95A70EB132882F88C0A59A55";
      var keySize = 128;
      var iterations = iterationCount = 10000;
      var passPhrase = "file encrypt decrypt passPhrase";
      var aesUtil = new AesUtil(keySize, iterationCount);
      var zip = new JSZip();

//5b8a9a6fbd62ae31dbed1e8a
      $('form').submit(function (e) {
        e.preventDefault();
        input = document.getElementById('docId');

        var url = "http://54.159.16.22:3001/getUserDocsById/"+input.value;
        console.log("URL: "+url);

        $.ajax({
          url: url,
          type: "get",
          processData: false,
          contentType: false,
          success: function(res){
            console.log("DATA: "+ res);
            $.ajax({
              url: "http://54.159.16.22:3001/uploads/" + res.path,
              // url: 'http://54.159.16.22:3001/uploads/path-1535373212779',
              type: "get",
              success: function (getRes) {
                console.log("success0");
              }
            });
          }
        });

        /*zipFile = input.files[0];
        var fd = new FormData();
        fd.append('path', zipFile);
        fd.append('documentName', zipFile.lastModified);
        fd.append('documentClass', zipFile.name);
        fd.append('description', 'sample document');
        $.ajax({
          url: "http://54.159.16.22:3001/uploadUserDoc",
          type: "post",
          data: fd,
          processData: false,
          contentType: false,
          success: function (res) {
            $.ajax({
              url: "http://54.159.16.22:3001/" + res.path,
              // url: 'http://54.159.16.22:3001/uploads/path-1535373212779',
              type: "get",
              success: function (getRes) {
                var data = new JSZip.external.Promise(function (resolve, reject) {
                  JSZipUtils.getBinaryContent(
                    'http://54.159.16.22:3001/' + res.path,
                    // 'http://54.159.16.22:3001/uploads/path-1535373212779',
                    function (err, data) {
                      if (err) {
                        reject(err);
                      } else {
                        resolve(data);
                      }
                    });
                }).then(function (data) {
                  JSZip.loadAsync(data).then(function (fileData) {
                    console.log(localStorage.getItem('fileName'));
                    var name = localStorage.getItem('fileName');
                    var type = localStorage.getItem('fileType');
                    localStorage.removeItem('fileName');
                    var string = new TextDecoder("utf-8").decode(fileData.files['nested/'+name]._data.compressedContent);
                    var decrypt = aesUtil.decrypt(salt, iv, passPhrase, string);
                    console.log(decrypt.split('data:text/plain;base64,')[1])
                    if(type == 'image'){
                      $('#image').attr('src', decrypt)
                    }else if(type = 'text'){
                      $('#result').text(atob(decrypt.split('data:text/plain;base64,')[1]));
                    }
                  });
                })
              }
            })
          }
        });*/
      });

      
  </script>
</body>

</html>