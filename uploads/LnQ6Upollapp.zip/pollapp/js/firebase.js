  // Initialize Firebase
  var config = {
    apiKey: "AIzaSyDAH4ttxo62nfrq_bWy1XHThcliADAkxSk",
    authDomain: "poll-4bd5d.firebaseapp.com",
    databaseURL: "https://poll-4bd5d.firebaseio.com",
    projectId: "poll-4bd5d",
    storageBucket: "poll-4bd5d.appspot.com",
    messagingSenderId: "421307063575"
  };
  firebase.initializeApp(config);
  